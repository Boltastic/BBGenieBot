var url = WebApp.getUrl({ command: "index" })

Bot.sendMessage("You can use this url as Web App:")
Api.sendMessage({ text: url })